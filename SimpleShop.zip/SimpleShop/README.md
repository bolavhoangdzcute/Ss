# SimpleShop

Plugin shop kiểu DonutSMP cho Paper 26.3 (Java 25), có sẵn hệ thống tiền tệ riêng.

## Cách hoạt động
- `/shop`: menu danh mục. Bấm vào danh mục, bấm vào vật phẩm sẽ mở bảng chọn số lượng
  (nút đỏ giảm, nút xanh tăng, ô xanh lá ở giữa hàng dưới để xác nhận mua).
- `/sell`: mở một cái rương, bỏ đồ vào rồi đóng rương lại là bán hết. Đồ không bán được sẽ được trả lại.
- Shop chỉ để mua. Bán đồ qua `/sell`.

## Lệnh
| Lệnh | Công dụng | Quyền |
|---|---|---|
| `/shop [danh-mục]` | Mở shop | `simpleshop.use` |
| `/shop reload` | Tải lại config và shop.yml | `simpleshop.admin` |
| `/sell` | Mở rương bán đồ | `simpleshop.use` |
| `/sell hand` / `/sell all` | Bán nhanh vật phẩm trên tay / cả túi đồ | `simpleshop.use` |
| `/balance [người-chơi]` (`/bal`, `/money`) | Xem số dư | `simpleshop.use` |
| `/pay <người-chơi> <số-tiền>` | Chuyển tiền | `simpleshop.pay` |
| `/eco <give\|take\|set> <người-chơi> <số-tiền>` | Quản lý tiền | `simpleshop.admin` |

Quyền `simpleshop.use`, `simpleshop.pay`, `simpleshop.balance.others` mặc định ai cũng có. `simpleshop.admin` mặc định chỉ OP.

## Build
### Cách 1: trên máy tính
Cần JDK 25. Mở terminal trong thư mục dự án và chạy `./gradlew build` (Windows: `gradlew.bat build`).
File jar nằm ở `build/libs/SimpleShop-1.0.0.jar`. Bỏ vào `plugins/` của server Paper 26.3 rồi khởi động lại.

### Cách 2: để GitHub build giúp (không cần cài gì)
1. Tạo repo GitHub, đưa toàn bộ nội dung thư mục này lên (nhớ cả thư mục `.github`).
2. Vào tab **Actions**, chờ workflow **Build** chạy xong.
3. Mở lần chạy đó, tải **SimpleShop** ở mục Artifacts, giải nén ra file `.jar`.

## Chỉnh bảng giá
Mở `plugins/SimpleShop/shop.yml`:

```yaml
categories:
  ores:
    name: "<aqua>Khoáng sản"
    icon: DIAMOND
    items:
      - { material: DIAMOND, buy: 300, sell: 120 }
```

`buy: -1` là không bán trong shop, `sell: -1` là không thu mua trong `/sell`. Sau khi sửa gõ `/shop reload`.

Lưu ý: chỉ bán được vật phẩm "nguyên bản" (không đổi tên, không phù phép, không hỏng).
