package vn.simpleshop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Loads shop.yml and performs buy / sell transactions. */
public final class ShopManager {

    public record ShopItem(Material material, double buy, double sell) {
        public boolean canBuy() {
            return buy > 0;
        }

        public boolean canSell() {
            return sell > 0;
        }
    }

    public record ShopCategory(String id, String name, Material icon, int slot, List<ShopItem> items) {
    }

    private static final int[] AUTO_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
    private static final int STORAGE_SIZE = 36;

    private final ShopPlugin plugin;
    private final Map<String, ShopCategory> categories = new LinkedHashMap<>();
    private final Map<Material, ShopItem> sellable = new HashMap<>();

    public ShopManager(ShopPlugin plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ loading

    public void load() {
        categories.clear();
        sellable.clear();

        File file = new File(plugin.getDataFolder(), "shop.yml");
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = yml.getConfigurationSection("categories");
        if (root == null) {
            plugin.getLogger().warning("shop.yml has no 'categories' section.");
            return;
        }

        Set<Integer> usedSlots = new HashSet<>();
        for (String id : root.getKeys(false)) {
            ConfigurationSection section = root.getConfigurationSection(id);
            if (section == null) {
                continue;
            }

            Material icon = Material.matchMaterial(section.getString("icon", "CHEST"));
            if (icon == null || !icon.isItem()) {
                icon = Material.CHEST;
            }

            List<ShopItem> items = new ArrayList<>();
            for (Map<?, ?> raw : section.getMapList("items")) {
                ShopItem item = parseItem(id, raw);
                if (item != null) {
                    if (item.canBuy()) {
                        items.add(item);
                    }
                    if (item.canSell()) {
                        sellable.putIfAbsent(item.material(), item);
                    }
                }
            }
            if (items.isEmpty()) {
                continue; // nothing to buy here, so the category is not shown in /shop
            }

            int slot = section.getInt("slot", -1);
            if (slot < 9 || slot > 35 || usedSlots.contains(slot)) {
                slot = nextFreeSlot(usedSlots);
            }
            if (slot < 0) {
                plugin.getLogger().warning("No free menu slot for category '" + id + "', skipping.");
                continue;
            }
            usedSlots.add(slot);

            String key = id.toLowerCase(Locale.ROOT);
            categories.put(key, new ShopCategory(key, section.getString("name", id), icon, slot, List.copyOf(items)));
        }
        plugin.getLogger().info("Loaded " + categories.size() + " shop categories.");
    }

    private ShopItem parseItem(String categoryId, Map<?, ?> raw) {
        Object name = raw.get("material");
        Material material = name == null ? null : Material.matchMaterial(String.valueOf(name));
        if (material == null || !material.isItem() || material.isAir()) {
            plugin.getLogger().warning("Category '" + categoryId + "': unknown item '" + name + "', skipping.");
            return null;
        }
        double buy = number(raw.get("buy"));
        double sell = number(raw.get("sell"));
        if (buy <= 0 && sell <= 0) {
            plugin.getLogger().warning("Category '" + categoryId + "': " + material + " has no buy or sell price, skipping.");
            return null;
        }
        return new ShopItem(material, buy, sell);
    }

    private static double number(Object value) {
        return value instanceof Number n ? n.doubleValue() : -1;
    }

    private static int nextFreeSlot(Set<Integer> used) {
        for (int slot : AUTO_SLOTS) {
            if (!used.contains(slot)) {
                return slot;
            }
        }
        return -1;
    }

    public Collection<ShopCategory> categories() {
        return categories.values();
    }

    public ShopCategory category(String id) {
        return categories.get(id.toLowerCase(Locale.ROOT));
    }

    // ------------------------------------------------------------------ buying

    public void buy(Player player, ShopItem item, int amount) {
        if (!item.canBuy()) {
            fail(player, "cannot-buy");
            return;
        }
        EconomyManager economy = plugin.economy();
        UUID id = player.getUniqueId();
        double total = EconomyManager.round(item.buy() * amount);

        if (!economy.has(id, total)) {
            fail(player, "not-enough-money",
                    Placeholder.unparsed("price", economy.format(total)),
                    Placeholder.unparsed("balance", economy.format(economy.balance(id))));
            return;
        }
        if (roomFor(player.getInventory(), item.material()) < amount) {
            fail(player, "inventory-full");
            return;
        }

        economy.withdraw(id, total);

        int left = amount;
        int stackSize = item.material().getMaxStackSize();
        while (left > 0) {
            int n = Math.min(left, stackSize);
            Map<Integer, ItemStack> rest = player.getInventory().addItem(new ItemStack(item.material(), n));
            for (ItemStack leftover : rest.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), leftover);
            }
            left -= n;
        }

        success(player, "bought",
                Placeholder.unparsed("amount", String.valueOf(amount)),
                itemName(item.material()),
                Placeholder.unparsed("price", economy.format(total)));
    }

    // ------------------------------------------------------------------ selling

    /**
     * Called when the /sell chest closes: pays for every sellable item inside and
     * gives everything else back to the player. Empties the inventory.
     */
    public void settle(Player player, Inventory inventory) {
        double total = 0;
        int count = 0;
        boolean returned = false;

        for (int i = 0; i < inventory.getSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (stack == null || stack.getType().isAir()) {
                continue;
            }
            inventory.setItem(i, null);

            ShopItem item = sellable.get(stack.getType());
            if (item != null && isPlain(stack, stack.getType())) {
                total += item.sell() * stack.getAmount();
                count += stack.getAmount();
            } else {
                giveBack(player, stack);
                returned = true;
            }
        }

        if (count > 0) {
            total = EconomyManager.round(total);
            plugin.economy().deposit(player.getUniqueId(), total);
            success(player, "sold-all",
                    Placeholder.unparsed("amount", String.valueOf(count)),
                    Placeholder.unparsed("money", plugin.economy().format(total)));
        } else if (returned) {
            fail(player, "nothing-to-sell");
        }
    }

    private static void giveBack(Player player, ItemStack stack) {
        for (ItemStack leftover : player.getInventory().addItem(stack).values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), leftover);
        }
    }

    /** /sell hand */
    public void sellHand(Player player) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) {
            fail(player, "hold-item");
            return;
        }
        ShopItem item = sellable.get(hand.getType());
        if (item == null || !isPlain(hand, hand.getType())) {
            fail(player, "cannot-sell");
            return;
        }
        int n = hand.getAmount();
        player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
        double total = EconomyManager.round(item.sell() * n);
        plugin.economy().deposit(player.getUniqueId(), total);

        success(player, "sold",
                Placeholder.unparsed("amount", String.valueOf(n)),
                itemName(hand.getType()),
                Placeholder.unparsed("money", plugin.economy().format(total)));
    }

    /** /sell all */
    public void sellInventory(Player player) {
        PlayerInventory inventory = player.getInventory();
        double total = 0;
        int count = 0;
        for (int i = 0; i < STORAGE_SIZE; i++) {
            ItemStack stack = inventory.getItem(i);
            if (stack == null || stack.getType().isAir()) {
                continue;
            }
            ShopItem item = sellable.get(stack.getType());
            if (item == null || !isPlain(stack, stack.getType())) {
                continue;
            }
            total += item.sell() * stack.getAmount();
            count += stack.getAmount();
            inventory.setItem(i, null);
        }
        if (count == 0) {
            fail(player, "nothing-to-sell");
            return;
        }
        total = EconomyManager.round(total);
        plugin.economy().deposit(player.getUniqueId(), total);

        success(player, "sold-all",
                Placeholder.unparsed("amount", String.valueOf(count)),
                Placeholder.unparsed("money", plugin.economy().format(total)));
    }

    // ------------------------------------------------------------------ helpers

    private void success(Player player, String key, TagResolver... resolvers) {
        player.sendMessage(plugin.msg(key, resolvers));
        plugin.playSound(player, true);
    }

    private void fail(Player player, String key, TagResolver... resolvers) {
        player.sendMessage(plugin.msg(key, resolvers));
        plugin.playSound(player, false);
    }

    private static TagResolver itemName(Material material) {
        return Placeholder.component("item", Component.translatable(material.translationKey()));
    }

    /** True if the stack is an unmodified item (no custom name, enchants, damage, ...). */
    private static boolean isPlain(ItemStack stack, Material material) {
        return stack != null && stack.getType() == material && stack.isSimilar(new ItemStack(material));
    }

    /** How many items of this material fit into the player's main inventory slots. */
    private static int roomFor(PlayerInventory inventory, Material material) {
        int max = material.getMaxStackSize();
        int room = 0;
        for (int i = 0; i < STORAGE_SIZE; i++) {
            ItemStack stack = inventory.getItem(i);
            if (stack == null || stack.getType().isAir()) {
                room += max;
            } else if (isPlain(stack, material)) {
                room += Math.max(0, max - stack.getAmount());
            }
        }
        return room;
    }
}
