package vn.simpleshop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.List;

public final class ShopPlugin extends JavaPlugin implements Listener {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private EconomyManager economy;
    private ShopManager shops;
    private ShopGui gui;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new File(getDataFolder(), "shop.yml").exists()) {
            saveResource("shop.yml", false);
        }

        economy = new EconomyManager(this);
        economy.load();
        shops = new ShopManager(this);
        shops.load();
        gui = new ShopGui(this);

        Bukkit.getPluginManager().registerEvents(gui, this);
        Bukkit.getPluginManager().registerEvents(this, this);

        Commands commands = new Commands(this);
        for (String name : List.of("shop", "balance", "pay", "eco", "sell")) {
            PluginCommand command = getCommand(name);
            if (command != null) {
                command.setExecutor(commands);
                command.setTabCompleter(commands);
            }
        }

        // Save balances every 30 seconds if anything changed.
        Bukkit.getScheduler().runTaskTimer(this, economy::saveIfDirty, 20L * 30, 20L * 30);
    }

    @Override
    public void onDisable() {
        // Plugin events no longer fire here, so settle open /sell chests by hand.
        if (gui != null && shops != null) {
            gui.settleOpenSellViews();
        }
        if (economy != null) {
            economy.save();
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        economy.createAccount(event.getPlayer().getUniqueId());
    }

    public void reloadAll() {
        reloadConfig();
        shops.load();
    }

    public EconomyManager economy() {
        return economy;
    }

    public ShopManager shops() {
        return shops;
    }

    public ShopGui gui() {
        return gui;
    }

    /** Parses a MiniMessage string. */
    public Component parse(String raw, TagResolver... resolvers) {
        return MM.deserialize(raw, resolvers);
    }

    /** A message from config.yml (messages.<key>) with the prefix prepended. */
    public Component msg(String key, TagResolver... resolvers) {
        String prefix = getConfig().getString("messages.prefix", "");
        String raw = getConfig().getString("messages." + key, "<red>Missing message: " + key);
        return MM.deserialize(prefix + raw, resolvers);
    }

    public void playSound(Player player, boolean success) {
        if (!getConfig().getBoolean("gui.sounds", true)) {
            return;
        }
        Sound sound = success ? Sound.ENTITY_EXPERIENCE_ORB_PICKUP : Sound.ENTITY_VILLAGER_NO;
        player.playSound(player.getLocation(), sound, 1f, 1f);
    }

    /** Finds an online player, or an offline player we already have an account for. */
    public OfflinePlayer findPlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            return online;
        }
        OfflinePlayer offline = Bukkit.getOfflinePlayerIfCached(name);
        if (offline != null && economy.hasAccount(offline.getUniqueId())) {
            return offline;
        }
        return null;
    }
}
