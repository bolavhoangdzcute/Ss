package vn.simpleshop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import vn.simpleshop.ShopManager.ShopCategory;
import vn.simpleshop.ShopManager.ShopItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * DonutSMP-style shop screens:
 * main menu -> category -> quantity selector (buy), plus a drop-in /sell chest.
 */
public final class ShopGui implements Listener {

    private static final int MAIN_SIZE = 36;
    private static final int CATEGORY_SIZE = 54;
    private static final int PAGE_SIZE = 45;
    private static final int QUANTITY_SIZE = 27;
    private static final int SELL_SIZE = 54;

    private static final int SLOT_MAIN_BALANCE = 4;

    private static final int SLOT_PREV = 45;
    private static final int SLOT_BACK = 48;
    private static final int SLOT_BALANCE = 49;
    private static final int SLOT_PAGE = 50;
    private static final int SLOT_NEXT = 53;

    private static final int SLOT_QTY_ITEM = 13;
    private static final int SLOT_CONFIRM = 22;
    private static final int SLOT_CANCEL = 18;

    /** Inventory holder that remembers what a shop screen contains. */
    public static final class Holder implements InventoryHolder {
        public enum Type { MAIN, CATEGORY, QUANTITY, SELL }

        private final Type type;
        private final ShopCategory category;
        private final int page;
        private int pages = 1;
        private ShopItem item;
        private int quantity = 1;
        private final Map<Integer, ShopItem> items = new HashMap<>();
        private final Map<Integer, ShopCategory> categories = new HashMap<>();
        private Inventory inventory;

        private Holder(Type type, ShopCategory category, int page) {
            this.type = type;
            this.category = category;
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private final ShopPlugin plugin;

    public ShopGui(ShopPlugin plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ opening

    public void openMain(Player player) {
        Holder holder = new Holder(Holder.Type.MAIN, null, 0);
        Inventory inventory = Bukkit.createInventory(holder, MAIN_SIZE, plugin.parse(cfg("gui.main-title", "Shop")));
        holder.inventory = inventory;

        fill(inventory, 0, MAIN_SIZE);
        inventory.setItem(SLOT_MAIN_BALANCE, balanceItem(player));
        for (ShopCategory category : plugin.shops().categories()) {
            holder.categories.put(category.slot(), category);
            inventory.setItem(category.slot(), categoryItem(category));
        }
        player.openInventory(inventory);
    }

    public void openCategory(Player player, ShopCategory category, int page) {
        int pages = Math.max(1, (category.items().size() + PAGE_SIZE - 1) / PAGE_SIZE);
        page = Math.max(0, Math.min(page, pages - 1));

        Holder holder = new Holder(Holder.Type.CATEGORY, category, page);
        holder.pages = pages;
        Inventory inventory = Bukkit.createInventory(holder, CATEGORY_SIZE,
                plugin.parse(cfg("gui.category-title", "Shop » <category>"),
                        Placeholder.parsed("category", category.name())));
        holder.inventory = inventory;

        fill(inventory, PAGE_SIZE, CATEGORY_SIZE);

        int start = page * PAGE_SIZE;
        for (int i = 0; i < PAGE_SIZE && start + i < category.items().size(); i++) {
            ShopItem item = category.items().get(start + i);
            holder.items.put(i, item);
            inventory.setItem(i, shopItem(item));
        }

        if (page > 0) {
            inventory.setItem(SLOT_PREV, named(Material.ARROW, plugin.parse(cfg("gui.prev", "Prev")), null));
        }
        if (page < pages - 1) {
            inventory.setItem(SLOT_NEXT, named(Material.ARROW, plugin.parse(cfg("gui.next", "Next")), null));
        }
        inventory.setItem(SLOT_BACK, named(Material.BARRIER, plugin.parse(cfg("gui.back", "Back")), null));
        inventory.setItem(SLOT_BALANCE, balanceItem(player));
        inventory.setItem(SLOT_PAGE, named(Material.PAPER, plugin.parse(cfg("gui.page-info", "<page>/<pages>"),
                Placeholder.unparsed("page", String.valueOf(page + 1)),
                Placeholder.unparsed("pages", String.valueOf(pages))), null));

        player.openInventory(inventory);
    }

    public void openQuantity(Player player, ShopCategory category, int page, ShopItem item) {
        Holder holder = new Holder(Holder.Type.QUANTITY, category, page);
        holder.item = item;
        Inventory inventory = Bukkit.createInventory(holder, QUANTITY_SIZE,
                plugin.parse(cfg("gui.quantity.title", "Quantity")));
        holder.inventory = inventory;
        renderQuantity(player, holder);
        player.openInventory(inventory);
    }

    /** /sell: a chest the player drops items into. Everything is sold when it is closed. */
    public void openSell(Player player) {
        Holder holder = new Holder(Holder.Type.SELL, null, 0);
        Inventory inventory = Bukkit.createInventory(holder, SELL_SIZE, plugin.parse(cfg("gui.sell.title", "Sell")));
        holder.inventory = inventory;
        player.openInventory(inventory);
    }

    /** Called on plugin disable: pays out / returns items from any open /sell chests. */
    public void settleOpenSellViews() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (top.getHolder(false) instanceof Holder holder && holder.type == Holder.Type.SELL) {
                plugin.shops().settle(player, top);
            }
        }
    }

    // ------------------------------------------------------------------ events

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder(false) instanceof Holder holder)) {
            return;
        }
        if (holder.type == Holder.Type.SELL) {
            return; // the sell chest behaves like a normal chest
        }
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (event.getClickedInventory() != event.getInventory()) {
            return;
        }
        int slot = event.getRawSlot();

        switch (holder.type) {
            case MAIN -> {
                ShopCategory category = holder.categories.get(slot);
                if (category != null) {
                    openCategory(player, category, 0);
                }
            }
            case CATEGORY -> clickCategory(player, holder, slot);
            case QUANTITY -> clickQuantity(player, holder, slot);
            default -> {
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder(false) instanceof Holder holder && holder.type != Holder.Type.SELL) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (event.getInventory().getHolder(false) instanceof Holder holder
                && holder.type == Holder.Type.SELL
                && event.getPlayer() instanceof Player player) {
            plugin.shops().settle(player, event.getInventory());
        }
    }

    private void clickCategory(Player player, Holder holder, int slot) {
        if (slot == SLOT_PREV && holder.page > 0) {
            openCategory(player, holder.category, holder.page - 1);
            return;
        }
        if (slot == SLOT_NEXT && holder.page < holder.pages - 1) {
            openCategory(player, holder.category, holder.page + 1);
            return;
        }
        if (slot == SLOT_BACK) {
            openMain(player);
            return;
        }
        ShopItem item = holder.items.get(slot);
        if (item != null) {
            openQuantity(player, holder.category, holder.page, item);
        }
    }

    private void clickQuantity(Player player, Holder holder, int slot) {
        List<Integer> steps = steps();
        int quantity = holder.quantity;

        if (slot >= 10 && slot <= 12) {
            int index = 12 - slot;
            if (index >= steps.size()) {
                return;
            }
            quantity -= steps.get(index);
        } else if (slot >= 14 && slot <= 16) {
            int index = slot - 14;
            if (index >= steps.size()) {
                return;
            }
            quantity += steps.get(index);
        } else if (slot == SLOT_CONFIRM) {
            plugin.shops().buy(player, holder.item, holder.quantity);
            renderQuantity(player, holder);
            return;
        } else if (slot == SLOT_CANCEL) {
            openCategory(player, holder.category, holder.page);
            return;
        } else {
            return;
        }

        int max = holder.item.material().getMaxStackSize();
        holder.quantity = Math.max(1, Math.min(max, quantity));
        renderQuantity(player, holder);
    }

    // ------------------------------------------------------------------ item builders

    private void renderQuantity(Player player, Holder holder) {
        Inventory inventory = holder.inventory;
        ShopItem item = holder.item;
        int quantity = holder.quantity;
        var economy = plugin.economy();
        double total = EconomyManager.round(item.buy() * quantity);

        fill(inventory, 0, QUANTITY_SIZE);

        List<Integer> steps = steps();
        for (int i = 0; i < steps.size(); i++) {
            int step = steps.get(i);
            inventory.setItem(12 - i, stepItem(Material.RED_STAINED_GLASS_PANE,
                    cfg("gui.quantity.decrease-name", "<red>-<step>"), step));
            inventory.setItem(14 + i, stepItem(Material.LIME_STAINED_GLASS_PANE,
                    cfg("gui.quantity.increase-name", "<green>+<step>"), step));
        }

        ItemStack display = new ItemStack(item.material());
        display.setAmount(quantity);
        List<Component> displayLore = List.of(noItalic(plugin.parse(cfg("gui.lore.buy-price", "Price: <price>"),
                Placeholder.unparsed("price", economy.format(item.buy())))));
        display.editMeta(meta -> meta.lore(displayLore));
        inventory.setItem(SLOT_QTY_ITEM, display);

        List<Component> confirmLore = new ArrayList<>();
        for (String line : plugin.getConfig().getStringList("gui.quantity.confirm-lore")) {
            confirmLore.add(plugin.parse(line,
                    Placeholder.unparsed("amount", String.valueOf(quantity)),
                    Placeholder.unparsed("total", economy.format(total)),
                    Placeholder.unparsed("balance", economy.format(economy.balance(player.getUniqueId())))));
        }
        inventory.setItem(SLOT_CONFIRM, named(Material.EMERALD_BLOCK,
                plugin.parse(cfg("gui.quantity.confirm-name", "Confirm")), confirmLore));
        inventory.setItem(SLOT_CANCEL, named(Material.BARRIER,
                plugin.parse(cfg("gui.quantity.cancel-name", "Cancel")), null));
    }

    private ItemStack stepItem(Material material, String nameTemplate, int step) {
        ItemStack stack = named(material,
                plugin.parse(nameTemplate, Placeholder.unparsed("step", String.valueOf(step))), null);
        stack.setAmount(Math.max(1, Math.min(64, step)));
        return stack;
    }

    private List<Integer> steps() {
        List<Integer> steps = new ArrayList<>();
        for (int step : plugin.getConfig().getIntegerList("gui.quantity.steps")) {
            if (step > 0 && steps.size() < 3) {
                steps.add(step);
            }
        }
        if (steps.isEmpty()) {
            steps.addAll(List.of(1, 8, 16));
        }
        return steps;
    }

    private ItemStack shopItem(ShopItem item) {
        List<Component> lore = new ArrayList<>();
        lore.add(plugin.parse(cfg("gui.lore.buy-price", "Price: <price>"),
                Placeholder.unparsed("price", plugin.economy().format(item.buy()))));
        lore.add(Component.empty());
        lore.add(plugin.parse(cfg("gui.lore.click-to-select", "Click to select quantity")));

        List<Component> finalLore = lore.stream().map(ShopGui::noItalic).toList();
        ItemStack stack = new ItemStack(item.material());
        stack.editMeta(meta -> meta.lore(finalLore));
        return stack;
    }

    private ItemStack categoryItem(ShopCategory category) {
        Component name = plugin.parse(category.name());
        Component lore = plugin.parse(cfg("gui.category-lore", "<count> items"),
                Placeholder.unparsed("count", String.valueOf(category.items().size())));
        return named(category.icon(), name, List.of(lore));
    }

    private ItemStack balanceItem(Player player) {
        String balance = plugin.economy().format(plugin.economy().balance(player.getUniqueId()));
        return named(Material.GOLD_INGOT,
                plugin.parse(cfg("gui.balance-name", "Balance")),
                List.of(plugin.parse(cfg("gui.balance-lore", "<balance>"), Placeholder.unparsed("balance", balance))));
    }

    private void fill(Inventory inventory, int from, int to) {
        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, Component.text(" "), null);
        for (int i = from; i < to; i++) {
            inventory.setItem(i, filler);
        }
    }

    private static ItemStack named(Material material, Component name, List<Component> lore) {
        ItemStack stack = new ItemStack(material);
        List<Component> finalLore = lore == null ? List.of() : lore.stream().map(ShopGui::noItalic).toList();
        stack.editMeta(meta -> {
            meta.displayName(noItalic(name));
            if (!finalLore.isEmpty()) {
                meta.lore(finalLore);
            }
        });
        return stack;
    }

    private static Component noItalic(Component component) {
        return component.decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    private String cfg(String path, String fallback) {
        return plugin.getConfig().getString(path, fallback);
    }
}
