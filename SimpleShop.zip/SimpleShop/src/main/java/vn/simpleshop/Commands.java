package vn.simpleshop;

import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import vn.simpleshop.ShopManager.ShopCategory;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** Handles /shop, /balance, /pay, /eco and /sell. */
public final class Commands implements TabExecutor {

    private final ShopPlugin plugin;

    public Commands(ShopPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "shop" -> shop(sender, args);
            case "balance" -> balance(sender, args);
            case "pay" -> pay(sender, args);
            case "eco" -> eco(sender, args);
            case "sell" -> sell(sender, args);
            default -> {
                return false;
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ /shop

    private void shop(CommandSender sender, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("simpleshop.admin")) {
                sender.sendMessage(plugin.msg("no-permission"));
                return;
            }
            plugin.reloadAll();
            sender.sendMessage(plugin.msg("reloaded"));
            return;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.msg("player-only"));
            return;
        }
        if (args.length == 0) {
            plugin.gui().openMain(player);
            return;
        }
        ShopCategory category = plugin.shops().category(args[0]);
        if (category == null) {
            player.sendMessage(plugin.msg("unknown-category", Placeholder.unparsed("category", args[0])));
            return;
        }
        plugin.gui().openCategory(player, category, 0);
    }

    // ------------------------------------------------------------------ /balance

    private void balance(CommandSender sender, String[] args) {
        EconomyManager economy = plugin.economy();

        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(plugin.msg("player-only"));
                return;
            }
            player.sendMessage(plugin.msg("balance-self",
                    Placeholder.unparsed("balance", economy.format(economy.balance(player.getUniqueId())))));
            return;
        }

        if (!sender.hasPermission("simpleshop.balance.others")) {
            sender.sendMessage(plugin.msg("no-permission"));
            return;
        }
        OfflinePlayer target = plugin.findPlayer(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.msg("player-not-found", Placeholder.unparsed("player", args[0])));
            return;
        }
        sender.sendMessage(plugin.msg("balance-other",
                Placeholder.unparsed("player", nameOf(target, args[0])),
                Placeholder.unparsed("balance", economy.format(economy.balance(target.getUniqueId())))));
    }

    // ------------------------------------------------------------------ /pay

    private void pay(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.msg("player-only"));
            return;
        }
        if (args.length != 2) {
            player.sendMessage(plugin.msg("usage-pay"));
            return;
        }
        OfflinePlayer target = plugin.findPlayer(args[0]);
        if (target == null) {
            player.sendMessage(plugin.msg("player-not-found", Placeholder.unparsed("player", args[0])));
            return;
        }
        if (target.getUniqueId().equals(player.getUniqueId())) {
            player.sendMessage(plugin.msg("pay-self"));
            return;
        }
        Double amount = parseAmount(args[1], false);
        if (amount == null) {
            player.sendMessage(plugin.msg("invalid-amount"));
            return;
        }

        EconomyManager economy = plugin.economy();
        if (!economy.withdraw(player.getUniqueId(), amount)) {
            player.sendMessage(plugin.msg("not-enough-money",
                    Placeholder.unparsed("price", economy.format(amount)),
                    Placeholder.unparsed("balance", economy.format(economy.balance(player.getUniqueId())))));
            return;
        }
        economy.deposit(target.getUniqueId(), amount);

        player.sendMessage(plugin.msg("pay-sent",
                Placeholder.unparsed("amount", economy.format(amount)),
                Placeholder.unparsed("player", nameOf(target, args[0]))));
        Player online = target.getPlayer();
        if (online != null) {
            online.sendMessage(plugin.msg("pay-received",
                    Placeholder.unparsed("amount", economy.format(amount)),
                    Placeholder.unparsed("player", player.getName())));
        }
    }

    // ------------------------------------------------------------------ /eco

    private void eco(CommandSender sender, String[] args) {
        if (!sender.hasPermission("simpleshop.admin")) {
            sender.sendMessage(plugin.msg("no-permission"));
            return;
        }
        if (args.length != 3) {
            sender.sendMessage(plugin.msg("usage-eco"));
            return;
        }
        String action = args[0].toLowerCase(Locale.ROOT);
        if (!List.of("give", "take", "set").contains(action)) {
            sender.sendMessage(plugin.msg("usage-eco"));
            return;
        }
        OfflinePlayer target = plugin.findPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(plugin.msg("player-not-found", Placeholder.unparsed("player", args[1])));
            return;
        }
        Double amount = parseAmount(args[2], action.equals("set"));
        if (amount == null) {
            sender.sendMessage(plugin.msg("invalid-amount"));
            return;
        }

        EconomyManager economy = plugin.economy();
        UUID id = target.getUniqueId();
        String name = nameOf(target, args[1]);

        switch (action) {
            case "give" -> {
                economy.deposit(id, amount);
                sender.sendMessage(plugin.msg("eco-give",
                        Placeholder.unparsed("amount", economy.format(amount)),
                        Placeholder.unparsed("player", name),
                        Placeholder.unparsed("balance", economy.format(economy.balance(id)))));
            }
            case "take" -> {
                double taken = Math.min(amount, economy.balance(id));
                economy.withdraw(id, taken);
                sender.sendMessage(plugin.msg("eco-take",
                        Placeholder.unparsed("amount", economy.format(taken)),
                        Placeholder.unparsed("player", name),
                        Placeholder.unparsed("balance", economy.format(economy.balance(id)))));
            }
            default -> {
                economy.set(id, amount);
                sender.sendMessage(plugin.msg("eco-set",
                        Placeholder.unparsed("player", name),
                        Placeholder.unparsed("balance", economy.format(economy.balance(id)))));
            }
        }
    }

    // ------------------------------------------------------------------ /sell

    private void sell(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.msg("player-only"));
            return;
        }
        if (args.length == 0) {
            plugin.gui().openSell(player);
            return;
        }
        if (args.length != 1) {
            player.sendMessage(plugin.msg("usage-sell"));
            return;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "hand" -> plugin.shops().sellHand(player);
            case "all" -> plugin.shops().sellInventory(player);
            default -> player.sendMessage(plugin.msg("usage-sell"));
        }
    }

    // ------------------------------------------------------------------ tab completion

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "shop" -> {
                if (args.length == 1) {
                    List<String> options = new ArrayList<>();
                    for (ShopCategory category : plugin.shops().categories()) {
                        options.add(category.id());
                    }
                    if (sender.hasPermission("simpleshop.admin")) {
                        options.add("reload");
                    }
                    return filter(options, args[0]);
                }
            }
            case "balance", "pay" -> {
                if (args.length == 1) {
                    return filter(onlineNames(), args[0]);
                }
            }
            case "eco" -> {
                if (args.length == 1) {
                    return filter(List.of("give", "take", "set"), args[0]);
                }
                if (args.length == 2) {
                    return filter(onlineNames(), args[1]);
                }
            }
            case "sell" -> {
                if (args.length == 1) {
                    return filter(List.of("hand", "all"), args[0]);
                }
            }
            default -> {
            }
        }
        return List.of();
    }

    // ------------------------------------------------------------------ helpers

    private static List<String> onlineNames() {
        List<String> names = new ArrayList<>();
        for (Player online : Bukkit.getOnlinePlayers()) {
            names.add(online.getName());
        }
        return names;
    }

    private static List<String> filter(List<String> options, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        return options.stream().filter(s -> s.toLowerCase(Locale.ROOT).startsWith(lower)).toList();
    }

    private static String nameOf(OfflinePlayer player, String fallback) {
        String name = player.getName();
        return name != null ? name : fallback;
    }

    /** Parses a positive (or, if allowed, zero) amount with at most 2 decimals. Returns null if invalid. */
    private static Double parseAmount(String text, boolean allowZero) {
        try {
            double value = Double.parseDouble(text);
            if (!Double.isFinite(value)) {
                return null;
            }
            value = EconomyManager.round(value);
            if (value < 0 || (value == 0 && !allowZero) || value > 1_000_000_000_000.0) {
                return null;
            }
            return value;
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
