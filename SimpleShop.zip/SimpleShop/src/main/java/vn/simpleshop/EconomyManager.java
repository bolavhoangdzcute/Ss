package vn.simpleshop;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Simple built-in economy. Balances are stored in plugins/SimpleShop/balances.yml. */
public final class EconomyManager {

    private final ShopPlugin plugin;
    private final File file;
    private final Map<UUID, Double> balances = new HashMap<>();
    private boolean dirty;

    public EconomyManager(ShopPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "balances.yml");
    }

    public void load() {
        balances.clear();
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yml.getConfigurationSection("balances");
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            try {
                balances.put(UUID.fromString(key), section.getDouble(key));
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Skipping invalid UUID in balances.yml: " + key);
            }
        }
    }

    public void saveIfDirty() {
        if (dirty) {
            save();
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, Double> entry : balances.entrySet()) {
            yml.set("balances." + entry.getKey(), entry.getValue());
        }
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
            dirty = false;
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save balances.yml: " + e.getMessage());
        }
    }

    public boolean hasAccount(UUID id) {
        return balances.containsKey(id);
    }

    public void createAccount(UUID id) {
        if (!balances.containsKey(id)) {
            double start = Math.max(0, plugin.getConfig().getDouble("currency.starting-balance", 0));
            balances.put(id, round(start));
            dirty = true;
        }
    }

    public double balance(UUID id) {
        return balances.getOrDefault(id, 0.0);
    }

    public boolean has(UUID id, double amount) {
        return balance(id) + 1e-9 >= amount;
    }

    public void deposit(UUID id, double amount) {
        if (amount < 0) {
            return;
        }
        set(id, balance(id) + amount);
    }

    public boolean withdraw(UUID id, double amount) {
        if (amount < 0 || !has(id, amount)) {
            return false;
        }
        set(id, balance(id) - amount);
        return true;
    }

    public void set(UUID id, double amount) {
        balances.put(id, Math.max(0, round(amount)));
        dirty = true;
    }

    public String format(double amount) {
        String prefix = plugin.getConfig().getString("currency.prefix", "$");
        String suffix = plugin.getConfig().getString("currency.suffix", "");
        DecimalFormat df = new DecimalFormat("#,##0.##", DecimalFormatSymbols.getInstance(Locale.US));
        return prefix + df.format(amount) + suffix;
    }

    public static double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
